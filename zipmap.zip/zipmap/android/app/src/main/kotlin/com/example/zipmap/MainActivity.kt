package com.example.zipmap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
